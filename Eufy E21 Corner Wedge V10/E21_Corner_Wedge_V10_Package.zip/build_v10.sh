#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
openscad -o V10_full_master.stl -D 'part="full"' E21_Corner_Wedge_V10.scad
for part in left right left_print right_print keys_print keys_assembled print_all; do
    openscad -o "V10_${part}.stl" -D "part=\"${part}\"" E21_Corner_Wedge_V10.scad
done
