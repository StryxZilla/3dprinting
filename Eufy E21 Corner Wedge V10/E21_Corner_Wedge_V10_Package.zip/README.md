# Eufy E21 — V10 compact 90° inside-corner wedge (prototype)

This is a **real STL/CAD prototype**, not a rendering. It is based on the user's previously supplied angled Eufy E21 mounting geometry. The camera-facing mating cap and the two retaining hooks are carried over from that geometry; the support behind it has been redesigned into a solid V-backed wedge that sits across a nominal **90° inside wall corner**, without wide mounting wings.

## Shape and mounting

- Nominal corner: **90°**; rear faces rest against the two walls, oriented 45° from the outward bisector.
- Camera faces straight out on the corner bisector (45° to either wall).
- Fixed tilt relative to the wall: **25°** as on the previous V9 angled mounting face.
- Face outer dimension: approximately **57.3 mm wide** and **51.9 mm vertically projected**, using the original mounting profile.
- Wedge projection from the inside corner: **35 mm at the face center; 47.2 mm maximum along its high end**. The thickness varies across the circular face.
- **Four angled screw channels**, two per wall, each perpendicular to its wall's contact face. #6 / small #8 flat-head screw geometry is provisional: 4.2 mm shank passages, 8.1 mm head cones, **82° countersinks**, and 9.2 mm screwdriver-access bores. Use actual fastener dimensions before relying on the model.
- **Cable channel:** 7 mm wide and approximately 7 mm deep at the rear centerline, opening out the vertical ends of the wedge. Fit to actual E21 cable diameter.
- **Two printed halves** divided between the original E21 retaining hooks. Each half is independently secured by two screws to its wall. Two loose **3.8 mm square, 16.4 mm long alignment keys** sit in slightly larger blind sockets across the joint. The keys align the halves but **are not by themselves a pull-apart locking mechanism**; wall screws carry the retention loads.
- Clearance between printed halves: 0.4 mm total. The original hooks have been carried over, not verified with the E21 camera in the final assembly.

## Printing

Use **`E21_Corner_Wedge_V10_PRINT_ALL.stl`** in Bambu Studio; both wedge halves are positioned on their flat split faces so hook layer orientation is improved. Print the two alignment keys alongside them. Individual oriented STLs are also included. Suggested starting settings for PETG on Bambu P2S: 0.16 mm layer height, 6 walls, 35–40% gyroid infill, 6 top/bottom layers, and 6–8 mm brim. Preview toolpaths; use manual supports only if required and avoid support marks on the locking hooks.

Do **not** print the **`V10_full_master.stl`** as the final mount: that is an intermediate *solid master* from which the separate halves are derived. `V10_Assembled_Reference.stl` is for visual inspection; the assembled parts deliberately have a 0.4 mm split gap.

## Rebuild / modify

The included OpenSCAD file uses `original_mount.stl`, `v5_slim_6mm_wedge.stl`, and the intermediate `V10_full_master.stl`. First build the master from source and then export the printable components:

```sh
openscad -o V10_full_master.stl -D 'part="full"' E21_Corner_Wedge_V10.scad
openscad -o E21_Corner_Wedge_V10_PRINT_ALL.stl -D 'part="print_all"' E21_Corner_Wedge_V10.scad
```

To change the nominal 90° corner or tilt angle requires redesign, not simply modifying the nominal text. The existing geometry uses **25° and a 90° corner**.

## Critical verification before installation

1. **Test the E21 push-on then sideways slide-to-lock movement** and confirm hooks engage fully with no new wedge or screw recess interfering.
2. **Dry fit both walls**. Actual corners can differ from 90° or have plaster buildup; do not force the wedge flat against uneven drywall.
3. **Confirm screw size, anchor suitability, drive access and clearance**. Flat-head screws should seat below the interface, and the two wall screws per half should not split thin plastic.
4. **Confirm alignment-key fit** and load-test the mount in a safe location. The two halves and keys are watertight CAD solids, but **not physically tested or mechanically load rated**.
5. For use around a baby, keep both the camera and its power cable well outside the crib and child's reach. Don't rely on an untested printed mount where it could fall onto the crib.

**V10 is a fit-test prototype, not a certified load-bearing safety product.**
