"""Validate and pack Eufy E21 25-degree split wall-mount V9; runs after OpenSCAD STL exports."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import numpy as np
import trimesh

root = Path(__file__).parent
parts = ['left_print', 'right_print', 'keys_print', 'left_assembled', 'right_assembled']
meshes = {name: trimesh.load(root / f'{name}.stl', force='mesh') for name in parts}
for name, mesh in meshes.items():
    assert mesh.is_watertight and mesh.is_winding_consistent and mesh.volume > 0, name
    assert len(mesh.split()) == (2 if name == 'keys_print' else 1), name
for side in ['left_print', 'right_print']:
    assert abs(meshes[side].bounds[0, 2]) < 0.002

combined = trimesh.util.concatenate([meshes[k] for k in ['left_print', 'right_print', 'keys_print']])
assert combined.is_watertight and len(combined.split()) == 4
out = root / 'E21_SLANTED_SPLIT_CABLE_V9_PRINT_ALL.stl'
combined.export(out)
again = trimesh.load(out, force='mesh')
assert again.is_watertight and len(again.split()) == 4

package = root / 'E21_SLANTED_SPLIT_CABLE_V9.zip'
files = ['E21_SLANTED_SPLIT_CABLE_V9_PRINT_ALL.stl', 'left_print.stl', 'right_print.stl', 'keys_print.stl', 'left_assembled.stl', 'right_assembled.stl', 'e21_split_staggered_v9.scad', 'original_mount.stl', 'v5_slim_6mm_wedge.stl', 'README.md', 'build.py', 'V9_hole_comparison.png']
with ZipFile(package, 'w', compression=ZIP_DEFLATED, compresslevel=9) as archive:
    for file in files:
        archive.write(root / file, arcname=file)
with ZipFile(package) as archive:
    assert archive.testzip() is None
print(f'VALID V9: {len(combined.split())} watertight solids, {out.stat().st_size} bytes STL, {package.stat().st_size} bytes ZIP')
