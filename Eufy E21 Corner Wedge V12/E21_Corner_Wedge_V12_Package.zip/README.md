# Eufy E21 corner wedge — V12 (flat / 0° camera-face tilt)

This is the compact, two-piece **inside 90° wall corner wedge** derived from V11. Unlike V11, **the camera-facing plate is upright with no built-in 25° downward tilt**. It is still horizontally centered: 45° to each wall.

## Changes from V11

- Camera-facing disk changed from 25° downward to **0° vertical tilt**, retaining its original E21 sliding-hook relationship through a rigid 25° counter-rotation of both imported interface meshes.
- Rebuilt the underlying 90° wedge to reach the new level face. The projected camera disk is circular, rather than vertically foreshortened.
- Retained **two separately printable halves**, no alignment pins.
- Retained **four countersunk wall screws**, two per wall. Two are cross-joint clamping passages that go through both pieces; two are direct passages.
- Retained the recessed center power-cable route behind the bracket (nominal 7 mm width).
- Retained the same 0.24 mm nominal seam gap.

## Basic dimensions and hardware

- Mount front nominal diameter: **57.3 mm** (derived from radius 28.65 mm).
- Corner: **90° inside**, with wall-contact faces oriented ±45° to camera face.
- Camera vertical tilt: **0°**; point of view faces straight outward horizontally, pending camera's own pan/tilt settings.
- Front surface from wall corner at the center: approximately **35 mm**.
- Screw shaft clearance: **4.2 mm**, countersink head outer diameter **8.1 mm**, **82°**.
- Cross-clamping screws travel around **24 mm through plastic** before entering wall; estimated overall 50–55 mm screw length, depending on wall anchor/required embedment. Direct screws pass around **6 mm** through plastic; exact wall hardware must be checked physically.
- Center cable relief approximately **7 mm** wide (verify cable OD).

## Print guidance

- Use `E21_Corner_Wedge_V12_PRINT_ALL.stl` to place two parts with flat split faces on the build plate.
- Suggested material: **PETG**, 0.16–0.20 mm layer height, 6 walls, 35–40% gyroid infill, 6–8 mm brim. Inspect support requirements for side-entry countersinks and hook undersides.
- Avoid supports fused into the E21 slide-in latch features; inspect the slicing preview.

## Assembly / safety

This is an **untested CAD prototype**. STL watertightness is only a geometric validity check; it does not demonstrate camera retention, fastener holding strength, strength of printed layer bonds, or corner fit. Walls are not always precisely 90°. Verify the E21 fully seats and slides to its locked position, and use appropriate wall anchors. Check driver access with actual hardware before drilling. Keep camera and cable outside a baby's reach and do not install over a crib before mechanical testing.

## Contents

- `E21_Corner_Wedge_V12_PRINT_ALL.stl`: two halves arranged on split faces.
- `E21_Corner_Wedge_V12_LEFT.stl`, `_RIGHT.stl`: individual halves in assembled coordinates.
- `E21_Corner_Wedge_V12.scad`: editable OpenSCAD reconstruction.
- `V12_full_master.stl`: intermediate watertight full-body mesh referenced by the OpenSCAD split selectors.
- `original_mount.stl`, `v5_slim_6mm_wedge.stl`: original donor geometry needed for a full parametric rebuild of camera hook interface.
- Preview images and build script.

To regenerate the master from the donor STLs: `openscad -o V12_full_master.stl -D 'part="full"' E21_Corner_Wedge_V12.scad`. Then regenerate the left/right and print layout with `-D 'part="left"'`, `right`, and `print_all`. The `full` module generates the wedge and rotated E21 locking geometry; the latter modules use the saved master for computational efficiency.
