#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
openscad -o V12_full_master.stl -D 'part="full"' E21_Corner_Wedge_V12.scad
for p in left right print_all; do
  openscad -o "E21_Corner_Wedge_V12_${p^^}.stl" -D "part=\"${p}\"" E21_Corner_Wedge_V12.scad
done
